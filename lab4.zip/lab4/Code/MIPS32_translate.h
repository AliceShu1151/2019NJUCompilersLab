#include "MIPS32_type.h"


void MIPS32_translate();