#include "semantic_analysis.h"
#include "intercode_type.h"

void intercode_translate(TreeNode *root);